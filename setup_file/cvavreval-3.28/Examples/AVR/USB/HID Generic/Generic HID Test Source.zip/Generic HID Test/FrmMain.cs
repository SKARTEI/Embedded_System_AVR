using Microsoft.Win32.SafeHandles;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices; 

// ***********************************************************************
// Software License Agreement
//
// Licensor grants any person obtaining a copy of this software ("You") 
// a worldwide, royalty-free, non-exclusive license, for the duration of 
// the copyright, free of charge, to store and execute the Software in a 
// computer system and to incorporate the Software or any portion of it 
// in computer programs You write.   
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
// ***********************************************************************
// 
// Portions of this program are (C) Copyright by Pavel Haiduc, 
// HP InfoTech S.R.L. http://www.hpinfotech.ro        
// 
// Portions of this program are (C) Copyright by Jan Axelson, 
// Lakeview Research http://www.Lvr.com        
// 
// This software was written using Visual Studio 2010 Professional Edition 
// and building for the .NET Framework 4.0.
// 
// Purpose: 
// Demonstrates USB communications with a generic HID-class device
// using the CodeVisionAVR USB library on the device side.

using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Timers;

using System.Windows.Forms;

namespace GenericHid
{
    internal class FrmMain : System.Windows.Forms.Form 
    {
        private const Int32 myVendorID = 0x03EB;
        private const Int32 myProductID = 0x311F;
        
        #region '"Windows Form Designer generated code "' 
        public FrmMain() : base() 
        {               
            // This call is required by the Windows Form Designer.
            InitializeComponent(); 
        } 
        // Form overrides dispose to clean up the component list.
        protected override void Dispose( bool Disposing ) 
        { 
            if ( Disposing ) 
            { 
                if ( !( components == null ) ) 
                { 
                    components.Dispose(); 
                } 
            } 
            base.Dispose( Disposing ); 
        } 
        
        // Required by the Windows Form Designer
        private System.ComponentModel.IContainer components;
        private GroupBox groupBox1;
        private CheckBox ledBox4;
        private CheckBox ledBox3;
        private CheckBox ledBox2;
        private CheckBox ledBox1;
        private GroupBox groupBox2;
        private GroupBox groupBox3;
        private ToolTip toolTip1;
        private TextBox textStatus;
        private TextBox textReceivedData; 
        // NOTE: The following procedure is required by the Windows Form Designer
        // It can be modified using the Windows Form Designer.
        // Do not modify it using the code editor. 
       
        [ System.Diagnostics.DebuggerStepThrough() ]
        private void InitializeComponent() 
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.ledBox4 = new System.Windows.Forms.CheckBox();
            this.ledBox3 = new System.Windows.Forms.CheckBox();
            this.ledBox2 = new System.Windows.Forms.CheckBox();
            this.ledBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textReceivedData = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textStatus = new System.Windows.Forms.TextBox();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.ledBox4);
            this.groupBox1.Controls.Add(this.ledBox3);
            this.groupBox1.Controls.Add(this.ledBox2);
            this.groupBox1.Controls.Add(this.ledBox1);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(286, 51);
            this.groupBox1.TabIndex = 14;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Light LEDs";
            this.toolTip1.SetToolTip(this.groupBox1, "Light the corresponding LED(s) on the development board");
            // 
            // ledBox4
            // 
            this.ledBox4.AutoSize = true;
            this.ledBox4.Location = new System.Drawing.Point(191, 19);
            this.ledBox4.Name = "ledBox4";
            this.ledBox4.Size = new System.Drawing.Size(56, 17);
            this.ledBox4.TabIndex = 3;
            this.ledBox4.Text = "LED 4";
            this.toolTip1.SetToolTip(this.ledBox4, "Light LED 4 on the development board");
            this.ledBox4.UseVisualStyleBackColor = true;
            this.ledBox4.CheckedChanged += new System.EventHandler(this.ledBox4_CheckedChanged);
            // 
            // ledBox3
            // 
            this.ledBox3.AutoSize = true;
            this.ledBox3.Location = new System.Drawing.Point(131, 19);
            this.ledBox3.Name = "ledBox3";
            this.ledBox3.Size = new System.Drawing.Size(56, 17);
            this.ledBox3.TabIndex = 2;
            this.ledBox3.Text = "LED 3";
            this.toolTip1.SetToolTip(this.ledBox3, "Light LED 3 on the development board");
            this.ledBox3.UseVisualStyleBackColor = true;
            this.ledBox3.CheckedChanged += new System.EventHandler(this.ledBox3_CheckedChanged);
            // 
            // ledBox2
            // 
            this.ledBox2.AutoSize = true;
            this.ledBox2.Location = new System.Drawing.Point(71, 19);
            this.ledBox2.Name = "ledBox2";
            this.ledBox2.Size = new System.Drawing.Size(56, 17);
            this.ledBox2.TabIndex = 1;
            this.ledBox2.Text = "LED 2";
            this.toolTip1.SetToolTip(this.ledBox2, "Light LED 2 on the development board");
            this.ledBox2.UseVisualStyleBackColor = true;
            this.ledBox2.CheckedChanged += new System.EventHandler(this.ledBox2_CheckedChanged);
            // 
            // ledBox1
            // 
            this.ledBox1.AutoSize = true;
            this.ledBox1.Location = new System.Drawing.Point(11, 19);
            this.ledBox1.Name = "ledBox1";
            this.ledBox1.Size = new System.Drawing.Size(56, 17);
            this.ledBox1.TabIndex = 0;
            this.ledBox1.Text = "LED 1";
            this.toolTip1.SetToolTip(this.ledBox1, "Light LED 1 on the development board");
            this.ledBox1.UseVisualStyleBackColor = true;
            this.ledBox1.CheckedChanged += new System.EventHandler(this.ledBox1_CheckedChanged);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.textReceivedData);
            this.groupBox2.Location = new System.Drawing.Point(12, 69);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(286, 134);
            this.groupBox2.TabIndex = 15;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Received Report Data";
            // 
            // textReceivedData
            // 
            this.textReceivedData.Location = new System.Drawing.Point(11, 19);
            this.textReceivedData.Multiline = true;
            this.textReceivedData.Name = "textReceivedData";
            this.textReceivedData.Size = new System.Drawing.Size(263, 103);
            this.textReceivedData.TabIndex = 0;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textStatus);
            this.groupBox3.Location = new System.Drawing.Point(12, 219);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(286, 134);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Status";
            // 
            // textStatus
            // 
            this.textStatus.Location = new System.Drawing.Point(11, 19);
            this.textStatus.Multiline = true;
            this.textStatus.Name = "textStatus";
            this.textStatus.Size = new System.Drawing.Size(263, 103);
            this.textStatus.TabIndex = 0;
            // 
            // FrmMain
            // 
            this.ClientSize = new System.Drawing.Size(311, 365);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Arial", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Location = new System.Drawing.Point(21, 28);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "CodeVisionAVR Generic HID Test";
            this.Closed += new System.EventHandler(this.frmMain_Closed);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);

        }         
        #endregion 
        
        private IntPtr deviceNotificationHandle; 
        private Boolean exclusiveAccess;
		private FileStream fileStreamDeviceData;
        private SafeFileHandle hidHandle; 
        private String hidUsage; 
        private Boolean myDeviceDetected; 
        private String myDevicePathName;
		private Boolean transferInProgress = false;
        
        private DeviceManagement MyDeviceManagement = new DeviceManagement(); 
        private Hid MyHid = new Hid();
		private static System.Timers.Timer tmrReadTimeout;
		private static System.Timers.Timer tmrContinuousDataCollect;

        // Actions
        private const int AddStatus = 0;
        private const int AddRxData = 1;

        private byte ledState;
    
        internal FrmMain FrmMy; 
        
        //  This delegate has the same parameters as AccessForm.
        //  Used in accessing the application's form from a different thread.
        private delegate void MarshalToForm(int action, String textToAdd );
        
        private void StartReceiving()
        {
            //  Enable the timer event to trigger a set of transfers.
            tmrContinuousDataCollect.Enabled = true;
            tmrContinuousDataCollect.Start();
            ReadFromDevice(); 
        }

        private void StopReceiving()
        {
            // Disable the timer that triggers the reception
            tmrContinuousDataCollect.Enabled = false;
            tmrContinuousDataCollect.Stop();
            // Stop the timeout timer
            tmrReadTimeout.Stop();
        }

        //  Called when a WM_DEVICECHANGE message has arrived,
        //  indicating that a device has been attached or removed.
        //  m - a message with information about the device
        internal void OnDeviceChange(Message m) 
        {             
            try 
            {
                if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEARRIVAL)) 
                {                     
                    //  If WParam contains DBT_DEVICEARRIVAL, a device has been attached.
                    //  Find out if it's the device we're communicating with.
                    if (MyDeviceManagement.DeviceNameMatch(m, myDevicePathName))
                    {
                        textStatus.Text="Device attached.";
                        StartReceiving();
                    }
                }
                else if ((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEREMOVECOMPLETE)) 
                { 
                    //  If WParam contains DBT_DEVICEREMOVAL, a device has been removed.
                    //  Find out if it's the device we're communicating with.
                    if (MyDeviceManagement.DeviceNameMatch(m, myDevicePathName)) 
                    {
                        // Disable the timer that triggers the reception
                        StopReceiving();
                        textStatus.Text="Device removed."; 
                        //  Set MyDeviceDetected False so on the next data-transfer attempt,
                        //  FindTheHid() will be called to look for the device 
                        //  and get a new handle.
                        FrmMy.myDeviceDetected = false;
                        ledState = 0;
                        ledBox1.Checked = false;
                        ledBox2.Checked = false;
                        ledBox3.Checked = false;
                        ledBox4.Checked = false;
                        textReceivedData.Clear();
                    } 
                }                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        //  Uses a series of API calls to locate a HID-class device
        //  by its Vendor ID and Product ID.
        //  Returns True if the device is detected, False if not detected.
        private Boolean FindTheHid() 
        {             
            Boolean deviceFound = false; 
            String[] devicePathName = new String[ 128 ];
            Guid hidGuid = Guid.Empty; 
            Int32 memberIndex = 0;
            
            try 
            { 
                myDeviceDetected = false;
				CloseCommunications();

                //  ***
                //  API function: 'HidD_GetHidGuid
                
                //  Purpose: Retrieves the interface class GUID for the HID class.
                
                //  Accepts: 'A System.Guid object for storing the GUID.
                //  ***
                Hid.HidD_GetHidGuid( ref hidGuid );
                //  Fill an array with the device path names of all attached HIDs.
                deviceFound = MyDeviceManagement.FindDeviceFromGuid( hidGuid, ref devicePathName ); 
                //  If there is at least one HID, attempt to read the Vendor ID and Product ID
                //  of each device until there is a match or all devices have been examined.
                if (deviceFound) 
                {                     
                    memberIndex = 0; 
                    do 
                    { 
                        //  ***
                        //  API function:
                        //  CreateFile
                        
                        //  Purpose:
                        //  Retrieves a handle to a device.
                        
                        //  Accepts:
                        //  A device path name returned by SetupDiGetDeviceInterfaceDetail
                        //  The type of access requested (read/write).
                        //  FILE_SHARE attributes to allow other processes to access the device while this handle is open.
                        //  A Security structure or IntPtr.Zero. 
                        //  A creation disposition value. Use OPEN_EXISTING for devices.
                        //  Flags and attributes for files. Not used for devices.
                        //  Handle to a template file. Not used.
                        
                        //  Returns: a handle without read or write access.
                        //  This enables obtaining information about all HIDs, even system
                        //  keyboards and mice. 
                        //  Separate handles are used for reading and writing.
                        //  ***

						// Open the handle without read/write access to enable getting information about any HID, even system keyboards and mice.
						hidHandle = FileIO.CreateFile(devicePathName[memberIndex], 0,  FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE, IntPtr.Zero, FileIO.OPEN_EXISTING, 0, 0);

                        myDeviceDetected = false;
                        if (!hidHandle.IsInvalid)  
                        {                             
                            //  The returned handle is valid, 
                            //  so find out if this is the device we're looking for.
                            
                            //  Set the Size property of DeviceAttributes to the number of bytes in the structure.
                            MyHid.DeviceAttributes.Size = Marshal.SizeOf( MyHid.DeviceAttributes ); 
                            
                            //  ***
                            //  API function:
                            //  HidD_GetAttributes
                            
                            //  Purpose:
                            //  Retrieves a HIDD_ATTRIBUTES structure containing the Vendor ID, 
                            //  Product ID, and Product Version Number for a device.
                            
                            //  Accepts:
                            //  A handle returned by CreateFile.
                            //  A pointer to receive a HIDD_ATTRIBUTES structure.
                            
                            //  Returns:
                            //  True on success, False on failure.
                            //  ***                            
                            if (Hid.HidD_GetAttributes(hidHandle, ref MyHid.DeviceAttributes)) 
                            {                                
                                //  Find out if the device matches the one we're looking for.
                                if ( ( MyHid.DeviceAttributes.VendorID == myVendorID ) && ( MyHid.DeviceAttributes.ProductID == myProductID ) ) 
                                {                                     
                                    //  Display the information in form's list box.
                                    textStatus.Text="Device detected.\r\nVendor ID=0x" + Convert.ToString(MyHid.DeviceAttributes.VendorID, 16)+                                 
                                                    ", Product ID=0x" + Convert.ToString(MyHid.DeviceAttributes.ProductID, 16);
                                    myDeviceDetected = true; 
                                    
                                    //  Save the DevicePathName for OnDeviceChange().
                                    myDevicePathName = devicePathName[memberIndex];
                                    break;
                                } 
                            } 
                            //  It's not a match, so close the handle.
                            hidHandle.Close();
                        } 
                        
                        //  Keep looking until we find the device or there are no devices left to examine.
                        ++memberIndex;                         
                    } 
                    while (  ! ( ( myDeviceDetected || ( memberIndex == devicePathName.Length ) ) ) );                     
                } 
                
                if ( myDeviceDetected ) 
                {                     
                    //  The device was detected.
                    //  Register to receive notifications if the device is removed or attached.
                    var success = MyDeviceManagement.RegisterForDeviceNotifications( myDevicePathName, FrmMy.Handle, hidGuid, ref deviceNotificationHandle ); 
                    
                    //  Learn the capabilities of the device.
                    MyHid.Capabilities = MyHid.GetDeviceCapabilities( hidHandle ); 
                    
                    if ( success ) 
                    {                         
                        //  Find out if the device is a system mouse or keyboard.
                        hidUsage = MyHid.GetHidUsage( MyHid.Capabilities ); 
                        
						//Close the handle and reopen it with read/write access.
						hidHandle.Close();
						hidHandle = FileIO.CreateFile(myDevicePathName, FileIO.GENERIC_READ | FileIO.GENERIC_WRITE, FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE, IntPtr.Zero, FileIO.OPEN_EXISTING, 0, 0);
                        
						if ( hidHandle.IsInvalid ) 
                        {                      
							exclusiveAccess = true;
                            textStatus.Text="The device is a system " + hidUsage + "."; 
                        } 
                        else 
                        {
							if (MyHid.Capabilities.InputReportByteLength > 0)
							{
								//  Set the size of the Input report buffer. 
								Byte[] inputReportBuffer = null;
								inputReportBuffer = new Byte[MyHid.Capabilities.InputReportByteLength];	
								fileStreamDeviceData = new FileStream(hidHandle, FileAccess.Read | FileAccess.Write, inputReportBuffer.Length, false);
							}

							if (MyHid.Capabilities.OutputReportByteLength > 0)
							{
								Byte[] outputReportBuffer = null;
								outputReportBuffer = new Byte[MyHid.Capabilities.OutputReportByteLength];								
							} 
                            
                            //  Flush any waiting reports in the input buffer. (optional)
                            MyHid.FlushQueue(hidHandle);                             
                        } 
                    } 
                } 
                else 
                    //  The device wasn't detected.
                    textStatus.Text="Device not found."; 
                return myDeviceDetected;                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        //  Performs various application-specific functions that
        //  involve accessing the application's form.
        //  action - action to perform on the form
        //  formText - text that the form displays
        private void AccessForm(int action, String formText ) 
        {             
            try 
            { 
                //  Select an action to perform on the form:
                switch (action) 
                {
                    case AddStatus:
                        textStatus.Text = formText; 
                        break;

                    case AddRxData:
                        textReceivedData.Text = formText; 
                        break;
                } 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
		// Close the handle and FileStreams for a device.
		private void CloseCommunications()
		{
			if (fileStreamDeviceData != null) fileStreamDeviceData.Close();
			if ((hidHandle != null) && (!(hidHandle.IsInvalid))) hidHandle.Close();
			// The next attempt to communicate will get new handles and FileStreams.
			myDeviceDetected = false;
		}

        // Transmit a change of LED 1 state.
        private void ledBox1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ledBox1.Checked) ledState |= 1;
                else ledState &= 0xFE;
                WriteLEDState(ledState);
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }

        }

        // Transmit a change of LED 2 state.
        private void ledBox2_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ledBox2.Checked) ledState |= 2;
                else ledState &= 0xFD;
                WriteLEDState(ledState);
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
        }

        // Transmit a change of LED 3 state.
        private void ledBox3_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ledBox3.Checked) ledState |= 4;
                else ledState &= 0xFB;
                WriteLEDState(ledState);
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
        }

        // Transmit a change of LED 4 state.
        private void ledBox4_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (ledBox4.Checked) ledState |= 8;
                else ledState &= 0xF7;
                WriteLEDState(ledState);
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
        } 
        
        // Retrieves an Input report.
        private void ReadReport() 
        {             
            Byte[] inputReportBuffer = null; 
			try
			{
				//  Don't attempt to read reports if valid handles aren't available
                if (!hidHandle.IsInvalid)
                {
                    //  Read an Input report.

                    //  Don't attempt to send an Input report if the HID has no Input report.
                    //  (The HID spec requires all HIDs to have an interrupt IN endpoint,
                    //  which suggests that all HIDs must support Input reports.)
                    if (MyHid.Capabilities.InputReportByteLength > 0)
                    {
                        //  Set the size of the Input report buffer. 
                        inputReportBuffer = new Byte[MyHid.Capabilities.InputReportByteLength];

                        //  Read a report using interrupt transfers.                
                        //  To enable reading a report without blocking the main thread, this
                        //  application uses an asynchronous delegate.
                        IAsyncResult ar = null;
                        transferInProgress = true;

                        // Timeout if no report is available.
                        tmrReadTimeout.Start();

                        if (fileStreamDeviceData.CanRead)
                        {
                            fileStreamDeviceData.BeginRead(inputReportBuffer, 0, inputReportBuffer.Length, new AsyncCallback(GetInputReportData), inputReportBuffer);
                        }
                        else
                        {
                            CloseCommunications();
                            textStatus.Text = "The attempt to read an Input report has failed.";
                        }
                    }
                    else
                        textStatus.Text = "No attempt to read an Input report was made.\n\r" +
                                           "The HID doesn't have an Input report.";
                }
                else textStatus.Text = "Invalid handle.";
			}
			catch (Exception ex)
			{
				DisplayException(this.Name, ex);
				throw;
			}			
        }

        //  Sends an Output report with LED state data.
        private void WriteReport(byte data)
        {
            Byte[] outputReportBuffer = null;
            try
            {
                //  Don't attempt to write a report if valid handles aren't available
                if (!hidHandle.IsInvalid)
                {
                    //  Don't attempt to send an Output report if the HID has no Output report.
                    if (MyHid.Capabilities.OutputReportByteLength > 0)
                    {
                        //  Set the size of the Output report buffer.   
                        outputReportBuffer = new Byte[MyHid.Capabilities.OutputReportByteLength];

                        //  Store the report ID in the first byte of the buffer:
                        outputReportBuffer[0] = 0;

                        //  Store the report data following the report ID.
                        //  Use the data in the combo boxes on the form.
                        outputReportBuffer[1] = data;

                        // Fill the rest of the report data with 0s.
                        for (int i = 2; i < outputReportBuffer.Length; i++) outputReportBuffer[i] = 0;

                        //  Writes the report using an interrupt OUT endpoint
                        if (fileStreamDeviceData.CanWrite)
                        {
                            fileStreamDeviceData.Write(outputReportBuffer, 0, outputReportBuffer.Length);
                            textStatus.Text="An Output report has been written.";
                        }
                        else
                        {
                            CloseCommunications();
                            textStatus.Text="The attempt to write an Output report failed.";
                        }
                    }
                    else
                        textStatus.Text="The HID doesn't have an Output report.";
                }
                else textStatus.Text = "Invalid handle.";
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
        }
        
        //  Perform shutdown operations.
        private void frmMain_Closed( System.Object eventSender, System.EventArgs eventArgs ) 
        {             
            try 
            { 
                Shutdown();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            } 
        }         
        
        //  Perform startup operations.
        private void frmMain_Load( System.Object eventSender, System.EventArgs eventArgs ) 
        {             
            try 
            { 
                FrmMy = this; 
                Startup();                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        //  Retrieves Input report data and status information.
        //  This routine is called automatically when myInputReport.Read
        //  returns. Calls several marshaling routines to access the main form.
        //  ar - an object containing status information about the asynchronous operation.
        private void GetInputReportData(IAsyncResult ar) 
        {
            try 
            {
                Byte[] inputReportBuffer = (byte[])ar.AsyncState;	
          
                fileStreamDeviceData.EndRead(ar);

				tmrReadTimeout.Stop();

                if (ar.IsCompleted) 
                {
					MyMarshalToForm(AddStatus, "Read Input report with ID: " + String.Format( "{0:X2} ", inputReportBuffer[0]));

                    String rxData = "";
                    // Skip past report ID inputReportBuffer[0]
                    // Display received report data
                    for (int i = 1; i < inputReportBuffer.Length; i++) 
                    {                         
                        rxData = rxData + String.Format("{0:X2} ", inputReportBuffer[i]);
                        if ((i >= 0x10) && ((i & 0x0F)==0)) rxData = rxData + "\r\n";
                    }
                    MyMarshalToForm(AddRxData, rxData);
                } 
                else 
                    MyMarshalToForm(AddStatus, "Failure reading an Input report."); 
				transferInProgress = false;
            } 
            catch ( Exception ex ) 
            {
                StopReceiving();
            }             
        }         
        
        //  Enables accessing a form's controls from another thread 
        //  action - action to perform on the form
        //  textToDisplay - text that the form displays or the code uses for 
        //  another purpose. Actions that don't use text ignore this parameter.
        private void MyMarshalToForm(int action, String textToDisplay ) 
        {             
            object[] args = {action, textToDisplay}; 
            //  Execute AccessForm, passing the parameters in args.
            base.Invoke(new MarshalToForm(AccessForm), args);             
        }

		//  Periodically read data from the device.
		//  The timer is enabled only if cmdContinous has been clicked, 
		//  selecting continous (periodic) transfers.
		private void OnDataCollect(object source, ElapsedEventArgs e)
		{
			try
			{
				if (transferInProgress == false) ReadFromDevice();
			}
			catch (Exception ex)
			{
				DisplayException(this.Name, ex);
				throw;
			}
		}
		
		// System timer timeout if read via interrupt transfer doesn't return.
		private void OnReadTimeout(object source, ElapsedEventArgs e)
		{
			MyMarshalToForm(AddStatus, "Reading report timed out.");
			CloseCommunications();
			tmrReadTimeout.Stop();
		}
		        
        // The application sends a report.
        private void WriteLEDState(byte data) 
        {             
            try 
            { 
                //  If the device hasn't been detected, was removed, or timed out on a previous attempt
                //  to access it, look for the device.
                if (myDeviceDetected == false) myDeviceDetected = FindTheHid();                     
                if (myDeviceDetected) WriteReport(data);
            } 
            catch (Exception ex) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }

        // The application reads a report.
        private void ReadFromDevice()
        {
            try
            {
                //  If the device hasn't been detected, was removed, or timed out on a previous attempt
                //  to access it, look for the device.
                if (myDeviceDetected == false) myDeviceDetected = FindTheHid();
                if (myDeviceDetected) ReadReport();
            }
            catch (Exception ex)
            {
                DisplayException(this.Name, ex);
                throw;
            }
        }
        
        // Perform actions that must execute when the program ends.
        private void Shutdown() 
        {             
            try 
            {
				CloseCommunications();	
                //  Stop receiving notifications.
                MyDeviceManagement.StopReceivingDeviceNotifications( deviceNotificationHandle );                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex); 
                throw ; 
            }             
        } 
                
        // Perform actions that must execute when the program starts.
        private void Startup() 
        {            
            try 
            { 
                MyHid = new Hid();
                FindTheHid();
								
				tmrContinuousDataCollect = new System.Timers.Timer(1000);
				tmrContinuousDataCollect.Elapsed  += new ElapsedEventHandler(OnDataCollect);
				tmrContinuousDataCollect.Stop();
				tmrContinuousDataCollect.SynchronizingObject = this;

				tmrReadTimeout = new System.Timers.Timer(5000);			
				tmrReadTimeout.Elapsed += new ElapsedEventHandler(OnReadTimeout);				
				tmrReadTimeout.Stop();

                StartReceiving();
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }
               
        // Overrides WndProc to enable checking for and handling WM_DEVICECHANGE messages.
        protected override void WndProc(ref Message m) 
        {            
            try 
            { 
                //  The OnDeviceChange routine processes WM_DEVICECHANGE messages.
                if (m.Msg == DeviceManagement.WM_DEVICECHANGE) OnDeviceChange(m); 
                //  Let the base form process the message.
                base.WndProc( ref m );                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( this.Name, ex ); 
                throw ; 
            }             
        }         
        
        //  Provides a central mechanism for exception handling.
        //  Displays a message box that describes the exception.
        //  moduleName - the module where the exception occurred.
        //  param name - the exception
        internal static void DisplayException( String moduleName, Exception e ) 
        {             
            MessageBox.Show("Exception: \r\n" +
                            "Module: " + moduleName + 
                            "\r\nMethod: " + e.TargetSite.Name,
                            "Unexpected Exception", MessageBoxButtons.OK ); 
        } 
                
        [STAThread]
        internal static void Main() 
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new FrmMain()); 
        }
       
        private static FrmMain transDefaultFormFrmMain = null;

        internal static FrmMain TransDefaultFormFrmMain
        { 
        	get
        	{ 
        		if (transDefaultFormFrmMain == null) transDefaultFormFrmMain = new FrmMain();
        		return transDefaultFormFrmMain;
        	} 
        }

    }      
} 
