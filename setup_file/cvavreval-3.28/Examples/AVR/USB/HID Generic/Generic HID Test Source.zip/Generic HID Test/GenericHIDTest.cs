using System.Windows.Forms;

namespace GenericHid
{
    public class GenericHIDTest  
    { 
        public static void Main() 
        { 
           Application.Run(new FrmMain()); 
        } 
    } 
} 
