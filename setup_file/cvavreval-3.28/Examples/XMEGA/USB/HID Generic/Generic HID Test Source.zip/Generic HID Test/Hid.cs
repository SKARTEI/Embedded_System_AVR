using Microsoft.VisualBasic;
using Microsoft.Win32.SafeHandles; 
using System;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Windows.Forms;

//  For communicating with HID-class USB devices.
//  Includes routines for sending and receiving reports via control transfers and to 
//  retrieve information about and configure a HID.

namespace GenericHid
{    
    internal sealed partial class Hid  
    {         
        //  Used in error messages.
        private const String MODULE_NAME = "Hid"; 
        
        internal HIDP_CAPS Capabilities; 
        internal HIDD_ATTRIBUTES DeviceAttributes; 
        
        //  Remove any Input reports waiting in the buffer.
        //  
        //  hidHandle - a handle to a device.
        //  
        //  Returns True on success, False on failure.
        internal Boolean FlushQueue( SafeFileHandle hidHandle ) 
        {             
            Boolean success = false; 
            
            try 
            { 
                //  ***
                //  API function: HidD_FlushQueue
                
                //  Purpose: Removes any Input reports waiting in the buffer.
                
                //  Accepts: a handle to the device.
                
                //  Returns: True on success, False on failure.
                //  ***
                
                success = HidD_FlushQueue( hidHandle ); 
                
                return success;                 
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( MODULE_NAME, ex ); 
                throw ; 
            }             
        }         
        
        //  Retrieves a structure with information about a device's capabilities. 
        //  
        //  hidHandle - a handle to a device.
        //  
        //  Returns a HIDP_CAPS structure.
        internal HIDP_CAPS GetDeviceCapabilities( SafeFileHandle hidHandle ) 
        {             
            IntPtr preparsedData = new System.IntPtr(); 
            Int32 result = 0; 
            Boolean success = false;  

			try
			{
				//  ***
				//  API function: HidD_GetPreparsedData

				//  Purpose: retrieves a pointer to a buffer containing information about the device's capabilities.
				//  HidP_GetCaps and other API functions require a pointer to the buffer.

				//  Requires: 
				//  A handle returned by CreateFile.
				//  A pointer to a buffer.

				//  Returns:
				//  True on success, False on failure.
				//  ***

				success = HidD_GetPreparsedData(hidHandle, ref preparsedData);

				//  ***
				//  API function: HidP_GetCaps

				//  Purpose: find out a device's capabilities.
				//  For standard devices such as joysticks, you can find out the specific
				//  capabilities of the device.
				//  For a custom device where the software knows what the device is capable of,
				//  this call may be unneeded.

				//  Accepts:
				//  A pointer returned by HidD_GetPreparsedData
				//  A pointer to a HIDP_CAPS structure.

				//  Returns: True on success, False on failure.
				//  ***

				result = HidP_GetCaps(preparsedData, ref Capabilities);
				if ((result != 0))
				{
					//  ***
					//  API function: HidP_GetValueCaps

					//  Purpose: retrieves a buffer containing an array of HidP_ValueCaps structures.
					//  Each structure defines the capabilities of one value.
					//  This application doesn't use this data.

					//  Accepts:
					//  A report type enumerator from hidpi.h,
					//  A pointer to a buffer for the returned array,
					//  The NumberInputValueCaps member of the device's HidP_Caps structure,
					//  A pointer to the PreparsedData structure returned by HidD_GetPreparsedData.

					//  Returns: True on success, False on failure.
					//  ***                    
					
					Int32 vcSize = Capabilities.NumberInputValueCaps;
					Byte[] valueCaps = new Byte[vcSize];
					
					result = HidP_GetValueCaps(HidP_Input, valueCaps, ref vcSize, preparsedData);
					
					// (To use this data, copy the ValueCaps byte array into an array of structures.)                   

				}
			}
			catch (Exception ex)
			{
				DisplayException(MODULE_NAME, ex);
				throw;
			}
			finally
			{
				 //  ***
					//  API function: HidD_FreePreparsedData
                    
					//  Purpose: frees the buffer reserved by HidD_GetPreparsedData.
                    
					//  Accepts: A pointer to the PreparsedData structure returned by HidD_GetPreparsedData.
                    
					//  Returns: True on success, False on failure.
					//  ***

				if (preparsedData != IntPtr.Zero)
				{
					success = HidD_FreePreparsedData(preparsedData);
				}
			} 
            
            return Capabilities;             
        }

		//  Reads a Feature report from the device.
		//  
		//  hidHandle - the handle for learning about the device and exchanging Feature reports.	
		//  myDeviceDetected - tells whether the device is currently attached.
		//  inFeatureReportBuffer - contains the requested report.
        //
		//  Returns True on success
		internal Boolean GetFeatureReport(SafeFileHandle hidHandle, ref Byte[] inFeatureReportBuffer)
		{
            Boolean success = false;
			try
			{
				//  ***
				//  API function: HidD_GetFeature
				//  Attempts to read a Feature report from the device.

				//  Requires:
				//  A handle to a HID
				//  A pointer to a buffer containing the report ID and report
				//  The size of the buffer. 

				//  Returns: true on success, false on failure.
				//  ***                    

				success = HidD_GetFeature(hidHandle, inFeatureReportBuffer, inFeatureReportBuffer.Length);
                return success;
			}
			catch (Exception ex)
			{
				DisplayException(MODULE_NAME, ex);
				throw;
			}
		}             


        //  Creates a 32-bit Usage from the Usage Page and Usage ID. 
        //  Determines whether the Usage is a system mouse or keyboard.
        //  Can be modified to detect other Usages.
        //  
        //  MyCapabilities - a HIDP_CAPS structure retrieved with HidP_GetCaps. 
        //  
        //  Return s String describing the Usage.
        internal String GetHidUsage( HIDP_CAPS MyCapabilities ) 
        {             
            Int32 usage = 0; 
            String usageDescription = ""; 
            
            try 
            { 
                //  Create32-bit Usage from Usage Page and Usage ID.
                usage = MyCapabilities.UsagePage * 256 + MyCapabilities.Usage; 
                
                if ( usage == Convert.ToInt32( 0X102 ) )
                 { 
                    usageDescription = "mouse"; } 
                
                if ( usage == Convert.ToInt32( 0X106 ) )
                 { 
                    usageDescription = "keyboard"; }                   
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( MODULE_NAME, ex ); 
                throw ; 
            } 
            
            return usageDescription;             
        }


		//  Reads an Input report from the device using a control transfer.
		//  
		//  hidHandle - the handle for learning about the device and exchanging Feature reports.
		//  myDeviceDetected - tells whether the device is currently attached.
		//  inputReportBuffer - contains the requested report.
        //
		//  Returns True on success
		internal Boolean GetInputReportViaControlTransfer(SafeFileHandle hidHandle, ref Byte[] inputReportBuffer)
		{
            Boolean success = false; 
            try
			{
				//  ***
				//  API function: HidD_GetInputReport

				//  Purpose: Attempts to read an Input report from the device using a control transfer.
				//  Supported under Windows XP and later only.

				//  Requires:
				//  A handle to a HID
				//  A pointer to a buffer containing the report ID and report
				//  The size of the buffer. 

				//  Returns: true on success, false on failure.
				//  ***

				success = HidD_GetInputReport(hidHandle, inputReportBuffer, inputReportBuffer.Length + 1);
                return success;
			}
			catch (Exception ex)
			{
				DisplayException(MODULE_NAME, ex);
				throw;
			}
		} 
		        
        //  Retrieves the number of Input reports the host can store.
        //  
        //  hidDeviceObject - a handle to a device.
        //  numberOfInputBuffers - an integer to hold the returned value.
        //  
        //  Returns True on success, False on failure.
        internal Boolean GetNumberOfInputBuffers( SafeFileHandle hidDeviceObject, ref Int32 numberOfInputBuffers ) 
        {             
            Boolean success = false;

            try
            {
                    //  ***
                    //  API function: HidD_GetNumInputBuffers

                    //  Purpose: retrieves the number of Input reports the host can store.
                    //  Not supported by Windows 98 Gold.
                    //  If the buffer is full and another report arrives, the host drops the 
                    //  ldest report.

                    //  Accepts: a handle to a device and an integer to hold the number of buffers. 

                    //  Returns: True on success, False on failure.
                    //  ***

                    success = HidD_GetNumInputBuffers(hidDeviceObject, ref numberOfInputBuffers);
                    return success;

            }
            catch (Exception ex)
            {
                DisplayException( MODULE_NAME, ex ); 
                throw ; 
            }                       
        }

		//  Writes a Feature report to the device.
		//  
		//  outFeatureReportBuffer - contains the report ID and report data.
		//  hidHandle - handle to the device.
		//  
		//  Returns True on success. False on failure.
		internal Boolean SendFeatureReport(SafeFileHandle hidHandle, Byte[] outFeatureReportBuffer)
		{
			Boolean success = false;

			try
			{
				//  ***
				//  API function: HidD_SetFeature

				//  Purpose: Attempts to send a Feature report to the device.

				//  Accepts:
				//  A handle to a HID
				//  A pointer to a buffer containing the report ID and report
				//  The size of the buffer. 

				//  Returns: true on success, false on failure.
				//  ***

				success = HidD_SetFeature(hidHandle, outFeatureReportBuffer, outFeatureReportBuffer.Length);
                return success;
			}
			catch (Exception ex)
			{
				DisplayException(MODULE_NAME, ex);
				throw;
			}
		} 
            
            //  Writes an Output report to the device using a control transfer.
            //  
            //  outputReportBuffer - contains the report ID and report data.
            //  hidHandle - handle to the device.
            //  
            //  Returns True on success. False on failure.
            internal Boolean SendOutputReportViaControlTransfer(SafeFileHandle hidHandle, Byte[] outputReportBuffer) 
            {
                Boolean success = false; 
                try 
                { 
                    //  ***
                    //  API function: HidD_SetOutputReport
                    
                    //  Purpose: 
                    //  Attempts to send an Output report to the device using a control transfer.
                    //  Requires Windows XP or later.
                    
                    //  Accepts:
                    //  A handle to a HID
                    //  A pointer to a buffer containing the report ID and report
                    //  The size of the buffer. 
                    
                    //  Returns: true on success, false on failure.
                    //  ***                    
                   
                    success = HidD_SetOutputReport(hidHandle, outputReportBuffer, outputReportBuffer.Length + 1);
                    return success;
                } 
                catch ( Exception ex ) 
                { 
                    DisplayException( MODULE_NAME, ex ); 
                    throw ; 
                }                 
            }    
 
        //  Sets the number of input reports the host will store.
        //  
        //  hidDeviceObject - a handle to the device.
        //  numberBuffers - the requested number of input reports.
        //  
        //  Returns True on success. False on failure.
        internal Boolean SetNumberOfInputBuffers( SafeFileHandle hidDeviceObject, Int32 numberBuffers ) 
        {
            Boolean success = false;  
            try 
            { 
                    //  ***
                    //  API function: HidD_SetNumInputBuffers
                    
                    //  Purpose: Sets the number of Input reports the host can store.
                    //  If the buffer is full and another report arrives, the host drops the 
                    //  oldest report.
                    
                    //  Requires:
                    //  A handle to a HID
                    //  An integer to hold the number of buffers. 
                    
                    //  Returns: true on success, false on failure.
                    //  ***
                    
                    success = HidD_SetNumInputBuffers( hidDeviceObject, numberBuffers );
                    return success;                    
            } 
            catch ( Exception ex ) 
            { 
                DisplayException( MODULE_NAME, ex ); 
                throw ; 
            }            
        } 
                
        
        //  Provides a central mechanism for exception handling.
        //  Displays a message box that describes the exception.
        //  
        //  moduleName - the module where the exception occurred. 
        //  e - the exception 
        internal static void DisplayException( String moduleName, Exception e ) 
        {             
            MessageBox.Show( "Exception: " + e.Message + 
                "\r\nModule: " + moduleName + "\r\nMethod: " + e.TargetSite.Name, 
                "Unexpected Exception", MessageBoxButtons.OK ); 
        }         
    } 
} 
