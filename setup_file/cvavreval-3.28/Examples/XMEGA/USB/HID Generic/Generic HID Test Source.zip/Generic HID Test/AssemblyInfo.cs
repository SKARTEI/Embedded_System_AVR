using System.Reflection; 
using System.Runtime.CompilerServices; 
using System.Runtime.InteropServices; 

//  General Information about an assembly is controlled through the following
//  set of attributes. Change these attribute values to modify the information
//  associated with an assembly

using System;
using System.Collections;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
[assembly: AssemblyTitle("CodeVisionAVR Generic HID Test")]
[assembly: AssemblyDescription("www.hpinfotech.ro")]
[assembly: AssemblyCompany("HP InfoTech S.R.L.")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright � Pavel Haiduc, HP InfoTech S.R.L. 2014")]
[ assembly: AssemblyTrademark( "" ) ]
[ assembly: AssemblyCulture( "" ) ]

//  Version information for an assembly consists of the following four values:

// 	Major version
// 	Minor Version
// 	Revision
// 	Build Number

//  You can specify all the values or you can default the Revision and Build Numbers
//  by using the '*' as shown below
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersionAttribute("1.0.0.0")]
