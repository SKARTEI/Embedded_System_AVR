/*
 * $safeitemname$.c
 *
 * Created: $date$
 *  Author: $user$
 */ 

#include <io.h>

void main(void)
{
    while(1)
    {
        // Please write your application code here

    }
}